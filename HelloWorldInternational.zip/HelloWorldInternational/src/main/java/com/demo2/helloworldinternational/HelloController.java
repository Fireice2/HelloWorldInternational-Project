package com.demo2.helloworldinternational;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.net.URL;

public class HelloController {

    @FXML
    private ComboBox<String> dropdown;
    
    @FXML
    private Label welcomeText;

    @FXML
    public void initialize() {
        // List of all Languages
        String[] Languages = new String[] {
                "Despacito",
                "English", "Abkhaz", "Acehnese", "Acholi", "Afar", "Afrikaans", "Albanian", "Alur",
                "Amharic", "Arabic", "Armenian", "Assamese", "Avar", "Awadhi", "Aymara", "Azerbaijani",
                "Balinese", "Baluchi", "Bambara", "Baoulé", "Bashkir", "Basque", "Batak Karo",
                "Batak Simalungun", "Batak Toba", "Belarusian", "Bemba", "Bengali", "Betawi",
                "Bhojpuri", "Bikol", "Bosnian", "Breton", "Bulgarian", "Buryat", "Cantonese",
                "Catalan", "Cebuano", "Chamorro", "Chechen", "Chichewa",
                "Chinese (Simplified)", "Chinese (Traditional)", "Chuukese", "Chuvash",
                "Corsican", "Crimean Tatar (Cyrillic)", "Crimean Tatar (Latin)", "Croatian",
                "Czech", "Danish", "Dari", "Dhivehi", "Dinka", "Dogri", "Dombe", "Dutch",
                "Dyula", "Dzongkha", "Esperanto", "Estonian", "Ewe", "Faroese", "Fijian",
                "Filipino", "Finnish", "Fon", "French", "French (Canada)", "Frisian",
                "Friulian", "Fulani", "Ga", "Galician", "Georgian", "German", "Greek",
                "Guarani", "Gujarati", "Haitian Creole", "Hakha Chin", "Hausa", "Hawaiian",
                "Hebrew", "Hiligaynon", "Hindi", "Hmong", "Hungarian", "Hunsrik", "Iban",
                "Icelandic", "Igbo", "Ilocano", "Indonesian", "Inuktut (Latin)",
                "Inuktut (Syllabics)", "Irish", "Italian", "Jamaican Patois", "Japanese",
                "Javanese", "Jingpo", "Kalaallisut", "Kannada", "Kanuri", "Kapampangan",
                "Kazakh", "Khasi", "Khmer", "Kiga", "Kikongo", "Kinyarwanda", "Kituba",
                "Kokborok", "Komi", "Konkani", "Korean", "Krio",
                "Kurdish (Kurmanji)", "Kurdish (Sorani)", "Kyrgyz", "Lao", "Latgalian",
                "Latin", "Latvian", "Ligurian", "Limburgish", "Lingala", "Lithuanian",
                "Lombard", "Luganda", "Luo", "Luxembourgish", "Macedonian", "Madurese",
                "Maithili", "Makassar", "Malagasy", "Malay", "Malay (Jawi)", "Malayalam",
                "Maltese", "Mam", "Manx", "Maori", "Marathi", "Marshallese", "Marwadi",
                "Mauritian Creole", "Meadow Mari", "Meiteilon (Manipuri)", "Minang",
                "Mizo", "Mongolian", "Myanmar (Burmese)",
                "Nahuatl (Eastern Huasteca)", "Ndau", "Ndebele (South)",
                "Nepalbhasa (Newari)", "Nepali", "NKo", "Norwegian", "Nuer", "Occitan",
                "Odia (Oriya)", "Oromo", "Ossetian", "Pangasinan", "Papiamento", "Pashto",
                "Persian", "Polish", "Portuguese (Brazil)", "Portuguese (Portugal)",
                "Punjabi (Gurmukhi)", "Punjabi (Shahmukhi)", "Quechua", "Qʼeqchiʼ",
                "Romani", "Romanian", "Rundi", "Russian", "Sami (North)", "Samoan",
                "Sango", "Sanskrit", "Santali (Latin)", "Santali (Ol Chiki)",
                "Scots Gaelic", "Sepedi", "Serbian", "Sesotho", "Seychellois Creole",
                "Shan", "Shona", "Sicilian", "Silesian", "Sindhi", "Sinhala", "Slovak",
                "Slovenian", "Somali", "Spanish", "Sundanese", "Susu", "Swahili",
                "Swati", "Swedish", "Tahitian", "Tajik", "Tamazight",
                "Tamazight (Tifinagh)", "Tamil", "Tatar", "Telugu", "Tetum", "Thai",
                "Tibetan", "Tigrinya", "Tiv", "Tok Pisin", "Tongan", "Tshiluba",
                "Tsonga", "Tswana", "Tulu", "Tumbuka", "Turkish", "Turkmen", "Tuvan",
                "Twi", "Udmurt", "Ukrainian", "Urdu", "Uyghur", "Uzbek", "Venda",
                "Venetian", "Vietnamese", "Waray", "Welsh", "Wolof", "Xhosa", "Yakut",
                "Yiddish", "Yoruba", "Yucatec Maya", "Zapotec", "Zulu", "Pig-Latin"
        };

        // List of all Translated version of "Hello World"
        String[] Translated = new String[]{
                "No seriously, what language?","Hello World", "Салам Адунеи", "Halo Donya", "Apwoyo lobo", "Nagaale Baadal", "Hallo Wêreld", "Përshëndetje Botë", "Amothi ngom",
                "ሰላም አለም", "مرحبا بالعالم", "Բարև աշխարհ", "হেল্ল' ৱৰ্ল্ড", "Салам Дунял", "हैलो वर्ल्ड", "Suma Uraqpachan", "Salam Dünya",
                "Halo Jagat", "سلام دنیا", "Bonjour Monde", "Bonjour Monde", "Һаумыһығыҙ Донъя", "Kaixo Mundua", "Halo Dunia", "Horas Dunia",
                "Horas Dunia", "Прывітанне, свет", "Mwapoleni Icalo conse", "হ্যালো ওয়ার্ল্ড", "Halo Dunia", "नमस्कार दुनिया के बा", "Kumusta an Kinaban", "Zdravo svijete",
                "Salud Bed", "Здравей, свят", "Амар мэндэ Дэлхэй", "你好世界", "Hola món", "Kumusta Kalibutan", "Håfa na Mundo", "Салам маршал дуьне",
                "Moni Dziko Lapansi", "你好世界", "你好世界", "Kapong ngeni Fonufan", "Салам Тӗнче", "Salutu u mondu", "Селям алейкум Дюнья", "Selâm aleyküm Dünya",
                "Pozdrav svijete", "Ahoj světe", "Hej Verden", "سلام جهان", "ހެލޯ ވޯލްޑް", "Muɔny Pinynhom", "नमस्कार दुनिया", "Wapona Nyika",
                "Hallo wereld", "Bonjour Duniɲa", "ཧེ་ལོ་འཛམ་གླིང་།", "Saluton Mondo", "Tere maailm", "Mido gbe na Xexeame", "Hey heimur", "Saluton Mondo",
                "Kumusta Mundo", "Hei maailma", "Kudo Gbɛ ɔ", "Bonjour le monde", "Salut tout le monde", "Hallo wrâld", "Ciao mont", "On njaaraama Aduna",
                "Helo Jeŋ", "Ola Mundo", "გამარჯობა მსოფლიო", "Hallo Welt", "Γεια σου κόσμε", "Maitei Mundo", "હેલો વર્લ્ડ", "Bonjou Mond",
                "Hello Vawlei", "Sannu Duniya", "Aloha Honua", "שלום עולם", "Hello World", "हैलो वर्ल्ड", "Nyob Zoo Lub Ntiaj Teb", "Helló Világ",
                "Hallo Welt", "Halo Dunya", "Halló heimur", "Ndewo Ụwa", "Hello Lubong", "Halo Dunia", "Haluu nunarjuaq", "ᕼᐊᓘ ᓄᓇᕐᔪᐊᖅ",
                "Haigh a Dhomhanda", "Ciao mondo", "Hello World", "こんにちは世界", "Halo Donya", "Hello Mungkan", "Hallo Verden", "ಹಲೋ ವರ್ಲ್ಡ್",
                "Salam Dunya", "Kamusta yatu", "Сәлем әлем", "Khublei Pyrthei", "សួស្តីពិភពលោក", "Haro Ensi yoona", "Mbote Nsi-Ntoto", "Muraho Isi",
                "Mbote Inza", "Joto Swngchar", "Здравствуйте мир", "हॅलो वर्ल्ड", "안녕하세요 세상아", "Halo Wɔl", "Silav Cîhan", "سڵاو جیهان",
                "Салам дүйнө", "ສະບາຍດີຊາວໂລກ", "Sveicīņs Pasauļam .", "Salve Mundus", "Sveika, pasaule!", "Ciao Mondo", "Hallo Wereld", "Mbote Mokili",
                "Sveikas, pasauli", "Ciao Mondo", "Mwasuze mutya Ensi", "Mos Piny", "Moien Welt", "Здраво свете", "Halo Dunnya", "नमस्कार दुनिया",
                "Hallo Dunia", "Hello World", "Halo Dunia", "سلام دنيا", "ഹലോ വേൾഡ്", "Bongu Dinja", "B´a´n q´ij twitz tx´otx´", "Halloo yn Dooinney",
                "Kia ora te ao", "हॅलो वर्ल्ड", "Yokwe lal in", "नमस्कार दुनिया", "Bonzour Lemond", "Салам лийже Тӱня", "ꯍꯦꯂꯣ ꯋꯥꯔꯜꯗ꯫", "Halo Dunia",
                "Hello Khawvel", "Сайн уу Дэлхий", "မင်္ဂလာပါကမ္ဘာလောက", "Kuali kajki Tlaltipaktli", "Kwazuwai Nyika", "Sawubona iphasi", "ज्वजलपा हलिं", "नमस्ते संसार",
                "ߊߟߎ߫ ߣߌ߫ ߖߐ߫ ߘߎߢߊ߫", "Hallo verden", "Ɣëlö Wecmuɔ̱ɔ̱n", "Adieu Mond", "ନମସ୍କାର ବିଶ୍ୱ", "Akkam jirtu Addunyaa", "Салам Дуне", "Hello World",
                "Hola Mundu", "سلام نړی", "سلام دنیا", "Witaj świecie", "Olá Mundo", "Olá, mundo!", "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਦੁਨਿਆ", "ہیلو ورلڈ",
                "Allinllachu Mundo", "Chaab'il eere li Ruchich'och'", "Bachtalo Luma", "Salut Lume", "Muraho Isi", "Привет, мир", "Hei máilbmi", "Talofa Lalolagi",
                "Bonjour Monde", "नमस्कार विश्व", "Johar Duniya", "ᱡᱚᱦᱟᱨ ᱡᱮᱜᱮᱛ", "Halò an t-Saoghail", "Thobela Lefase", "Здраво свете", "Lefatše Lumela",
                "Bonzour Lemonn", "မႂ်ႇသုင်လုမ်ႈၾႃႉ", "Mhoro Nyika", "Ciao Munnu", "Witaj Świat", "هيلو ورلڊ", "හෙලෝ වර්ල්ඩ්", "Ahoj svet",
                "Pozdravljen svet", "Salaan Adduun", "Hola Mundo", "Halo Dunya", "DuniE wo xa sEwa", "Habari Dunia", "Sawubona Umhlaba", "Hej världen",
                "Aroha mai i te Ao nei", "Салом Ҷаҳон", "Azul Amaḍal", "ⴰⵣⵓⵍ ⴰⵎⴰⴹⴰⵍ", "வணக்கம் உலகம்", "Сәлам Дөнья", "హలో వరల్డ్", "Olá Mundu",
                "สวัสดีชาวโลก", "ཀྭ་ཡེ་འཛམ་གླིང་།", "ሰላም ዓለም", "Msugh ne cii", "Hello Wol", "Malo Mamani", "Muoyo wenu buloba bujima", "Xewani Misava",
                "Dumela Lefatshe", "ನಮಸ್ಕಾರ ಜಗತ್ತ್", "Monileni Charu", "Selam Dünya", "Salam Dünýä", "Экии, делегей", "Hello Wiase", "Ӟечбуресь, дунне",
                "Привіт, світ", "ہیلو ورلڈ", "سالام دۇنيا", "Salom Dunyo", "Lotsha Shango", "Ciao mondo", "Chào thế giới", "Kumusta Kalibutan",
                "Helo Byd", "Nanga def", "Molo Lizwe", "Дорооболорун Аан дойду", "העלא וועלט", "Mo ki O Ile Aiye", "Hola yóok'ol kaab", "Hola Mundo",
                "Sawubona Mhlaba", "elloHay orldWay"
        };

        // Dropdown Box with all languages
        dropdown.getItems().addAll(Languages);
        dropdown.getSelectionModel().selectFirst(); // selects English

        // Detects which language was selected and what index it was inside of languages list
        dropdown.setOnAction(_ -> {
            int index = dropdown.getSelectionModel().getSelectedIndex();

            // If you select Despacito
            if (index == 0)
            {
                URL resource = getClass().getResource("/Music/Despacito.mp3");
                assert resource != null;
                Media hit = new Media(resource.toExternalForm());

                MediaPlayer mediaPlayer = new MediaPlayer(hit);
                mediaPlayer.play();
            }
            welcomeText.setText(Translated[index]);
        });

        // Select a default value for dropdown
        dropdown.setValue("English");
    }
}