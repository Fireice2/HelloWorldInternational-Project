module com.demo2.helloworldinternational {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;

    opens com.demo2.helloworldinternational to javafx.fxml;
    exports com.demo2.helloworldinternational;
}